package team.keephealth.yjj.service.mpl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import team.keephealth.common.enums.AppHttpCodeEnum;
import team.keephealth.yjj.domain.entity.Article;
import team.keephealth.yjj.domain.vo.ResultVo;
import team.keephealth.yjj.mapper.ArticleMapper;
import team.keephealth.yjj.service.ArticleManageService;

@Service
public class ArticleManagerServiceImpl extends ServiceImpl<ArticleMapper, Article> implements ArticleManageService {

    @Autowired
    private ArticleMapper articleMapper;

    @Override
    public ResultVo updateCheck(Long id, int check){
        if (articleMapper.updateCheck(id, check) > 0)
            return new ResultVo(AppHttpCodeEnum.SUCCESS, "", baseMapper.selectById(id));
        else
            return new ResultVo(AppHttpCodeEnum.ERROR, "", "id = " + id);
    }

    @Override
    public ResultVo updateOpinion(Long id, String opinion){
        if (articleMapper.updateOpinion(id, opinion) > 0)
            return new ResultVo(AppHttpCodeEnum.SUCCESS, "", baseMapper.selectById(id));
        else
            return new ResultVo(AppHttpCodeEnum.ERROR, "", "id = " + id);
    }
}
