package team.keephealth.yjj.service;

import com.baomidou.mybatisplus.extension.service.IService;
import team.keephealth.yjj.domain.entity.Article;
import team.keephealth.yjj.domain.vo.ResultVo;

public interface ArticleQueryService extends IService<Article> {

    // 获取全部文章
    ResultVo queryAll();

    // 获取该作者全部文章
    /**
     * @param kind : 0-发布时间， 1-最后更改时间， 2-点赞数
     * @param direction ：0-倒序， 1-正序
     * @return
     */
    ResultVo queryByUser(int kind, int direction, Long id);

    // 按无作者排序获取
    /**
     * @param kind : 0-发布时间， 1-最后更改时间， 2-点赞数
     * @param direction ：0-倒序， 1-正序
     * @return
     */
    ResultVo queryByAll(int kind, int direction);

    // 关键词查找
    ResultVo queryByKeyword(String keyword);

    // 分页查询
    ResultVo queryByPage();
}
