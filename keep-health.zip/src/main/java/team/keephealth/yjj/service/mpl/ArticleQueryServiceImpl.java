package team.keephealth.yjj.service.mpl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import team.keephealth.common.enums.AppHttpCodeEnum;
import team.keephealth.yjj.domain.entity.Article;
import team.keephealth.yjj.domain.vo.ResultVo;
import team.keephealth.yjj.mapper.ArticleQueryMapper;
import team.keephealth.yjj.service.ArticleQueryService;

import java.util.List;

@Service
public class ArticleQueryServiceImpl extends ServiceImpl<ArticleQueryMapper, Article> implements ArticleQueryService  {

    @Autowired
    private ArticleQueryMapper articleQueryMapper;

    @Override
    public ResultVo queryAll(){
        List<Article> list = articleQueryMapper.selectList(null);
        if (list != null)
            return new ResultVo(AppHttpCodeEnum.SUCCESS, "", list);
        else
            return new ResultVo(AppHttpCodeEnum.ERROR, "获取数列为空", null);
    }

    @Override
    public ResultVo queryByUser(int kind, int direction, Long id){
        if (kind > 2 || kind < 0)
            return new ResultVo(AppHttpCodeEnum.ERROR, "类型参数错误", "kind ：" + kind);
        if (direction > 1 || direction < 0)
            return new ResultVo(AppHttpCodeEnum.ERROR, "排序参数错误", "direction : " + direction);
        List<Article> list = articleQueryMapper.queryByUser(kind, direction, id);
        if (list != null)
            return new ResultVo(AppHttpCodeEnum.SUCCESS, "", list);
        else
            return new ResultVo(AppHttpCodeEnum.ERROR, "查询数据量为0",
                    "kind ：" + kind + "direction : "+direction+"id : "+id);
    }

    @Override
    public ResultVo queryByAll(int kind, int direction){
        if (kind > 2 || kind < 0)
            return new ResultVo(AppHttpCodeEnum.ERROR, "类型参数错误", "kind ：" + kind);
        if (direction > 1 || direction < 0)
            return new ResultVo(AppHttpCodeEnum.ERROR, "排序参数错误", "direction : " + direction);
        List<Article> list = articleQueryMapper.queryByAll(kind, direction);
        if (list != null)
            return new ResultVo(AppHttpCodeEnum.SUCCESS, "", list);
        else
            return new ResultVo(AppHttpCodeEnum.ERROR, "查询数据量为0",
                    "kind ：" + kind + "direction : " + direction);
    }

    @Override
    public ResultVo queryByKeyword(String keyword) {
        List<Article> list = articleQueryMapper.queryByKeyword(keyword);
        if (list != null)
            return new ResultVo(AppHttpCodeEnum.SUCCESS, "", list);
        else
            return new ResultVo(AppHttpCodeEnum.ERROR, "查询数据量为0", "keyword : " + keyword);
    }

    @Override
    public ResultVo queryByPage(){
        return null;
    }
}