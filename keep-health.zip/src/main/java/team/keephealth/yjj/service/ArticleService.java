package team.keephealth.yjj.service;

import com.baomidou.mybatisplus.extension.service.IService;
import team.keephealth.yjj.domain.dto.ArticleInfoDto;
import team.keephealth.yjj.domain.entity.Article;
import team.keephealth.yjj.domain.vo.ResultVo;

public interface ArticleService extends IService<Article> {

    // 添加
    ResultVo addArticle(ArticleInfoDto article);

    // 删除
    ResultVo deleteArticle(Long id);

    // 更改
    ResultVo updateArticle(ArticleInfoDto dto);

    // 获取详细信息
    ResultVo getDetail(Long id);
}
