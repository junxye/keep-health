package team.keephealth.yjj.service;

import com.baomidou.mybatisplus.extension.service.IService;
import team.keephealth.yjj.domain.entity.Article;
import team.keephealth.yjj.domain.vo.ResultVo;

public interface ArticleManageService extends IService<Article> {

    // 更改审核状态
    ResultVo updateCheck(Long id, int check);

    // 更改审核评语
    ResultVo updateOpinion(Long id, String opinion);
}
