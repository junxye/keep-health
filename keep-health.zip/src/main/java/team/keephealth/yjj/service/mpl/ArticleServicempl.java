package team.keephealth.yjj.service.mpl;

import org.springframework.security.core.context.SecurityContextHolder;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import team.keephealth.common.enums.AppHttpCodeEnum;
import team.keephealth.common.utils.SecurityUtils;
import team.keephealth.yjj.domain.dto.ArticleInfoDto;
import team.keephealth.yjj.domain.entity.Article;
import team.keephealth.yjj.domain.entity.Content;
import team.keephealth.yjj.domain.vo.ResultVo;
import team.keephealth.yjj.mapper.ArticleMapper;
import team.keephealth.yjj.mapper.ContentMapper;
import team.keephealth.yjj.service.ArticleService;

@Service
public class ArticleServicempl extends ServiceImpl<ArticleMapper, Article> implements ArticleService {

    @Autowired
    private ArticleMapper articleMapper;
    @Autowired
    private ContentMapper contentMapper;

    @Override
    public ResultVo addArticle(ArticleInfoDto dto){
        Long id = SecurityUtils.getLoginUser().getUser().getId();
        Article article = new Article(dto.getTitle(), dto.getWords());
        Content content = new Content(dto);
        article.setAccount(SecurityUtils.getLoginUser().getUser().getAccount());
        article.setId(id);
        content.setAccount(article.getAccount());
        content.setAccountId(id);
        article.setArticleCheck(0);
        int a = articleMapper.insert(article);
        int b = contentMapper.insert(content);
        if (a > 0 && b > 0)
            return new ResultVo(AppHttpCodeEnum.SUCCESS, "", articleMapper.selectByAccount(article.getAccount()));
        else{
            if (a <= 0 && b <= 0)
                return new ResultVo(AppHttpCodeEnum.ERROR,"", dto);
            else if (a <= 0) {
                contentMapper.deleteById(contentMapper.selectLast(id));
                return new ResultVo(AppHttpCodeEnum.ERROR, "用户信息存入错误", article);
            }
            else {
                articleMapper.deleteById(articleMapper.selectLast(id));
                return new ResultVo(AppHttpCodeEnum.ERROR, "文章数据存入错误", content);
            }
        }
    }

    @Override
    public ResultVo deleteArticle(Long id){
        if (baseMapper.deleteById(id) > 0)
            return new ResultVo(AppHttpCodeEnum.SUCCESS, "", "");
        else
            return new ResultVo(AppHttpCodeEnum.ERROR, "", articleMapper.selectById(id));
    }

    @Override
    public ResultVo updateArticle(ArticleInfoDto dto) {
        if (dto.getId() == null)
            return new ResultVo(AppHttpCodeEnum.ERROR, "获取文章编号失败", dto);
        Article a_return = articleMapper.selectById(dto.getId());
        Content c_return = contentMapper.selectByArticle(dto.getId());
        Article article = new Article(dto.getTitle(), dto.getWords());
        article.setArticleCheck(0);
        Content content = new Content(dto);
        int a = articleMapper.updateById(article);
        int b = contentMapper.updateByArticle(content);
        if (a > 0 && b > 0)
            return new ResultVo(AppHttpCodeEnum.SUCCESS, "", contentMapper.selectByArticle(dto.getId()));
        else{
            if (a <= 0 && b <= 0)
                return new ResultVo(AppHttpCodeEnum.ERROR,"", dto);
            else if (a <= 0) {
                contentMapper.updateByArticle(c_return);
                return new ResultVo(AppHttpCodeEnum.ERROR, "用户信息存入错误", article);
            }
            else {
                articleMapper.updateById(a_return);
                return new ResultVo(AppHttpCodeEnum.ERROR, "文章数据存入错误", content);
            }
        }
    }

    @Override
    public ResultVo getDetail(Long id){
        Article article = baseMapper.selectById(id);
        if (article != null)
            return new ResultVo(AppHttpCodeEnum.SUCCESS, "", article);
        else
            return new ResultVo(AppHttpCodeEnum.ERROR, "", "id = " + id);
    }
}
