package team.keephealth.yjj.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;
import team.keephealth.yjj.domain.entity.Content;

@Mapper
@Repository
public interface ContentMapper extends BaseMapper<Content> {

    // 获取最后一个数据id
    int selectLast(Long id);

    // 根据article编号更新
    int updateByArticle(Content content);

    // 根据article编号获取信息
    Content selectByArticle(Long id);
}
