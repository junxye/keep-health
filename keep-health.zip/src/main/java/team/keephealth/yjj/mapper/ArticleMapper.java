package team.keephealth.yjj.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import team.keephealth.yjj.domain.entity.Article;

@Mapper
@Repository
public interface ArticleMapper extends BaseMapper<Article>{

    // 根据账号查找
    Article selectByAccount(String account);

    // 更改审核状态
    int updateCheck(Long id, int check);

    // 更改评语
    int updateOpinion(Long id, String opinion);

    // 获取最后一个数据id
    int selectLast(Long id);

    // 获取章节id
    int getContentId(Long id);
}
