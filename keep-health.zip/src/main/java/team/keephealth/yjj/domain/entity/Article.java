package team.keephealth.yjj.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Data
@EqualsAndHashCode(callSuper = false)
@Table(name = "sys_article")
@AllArgsConstructor
@NoArgsConstructor
public class Article {

    @Id
    private Long id;
    // 账号
    private String account;
    // 账号id
    @Column(name = "account_id")
    private Long accountId;
    // 文章内容id
    @Column(name = "content_id")
    private Long contentId;
    // 标题
    private String title;
    // 前100字内容
    private String words;
    // 审核: 0未审核， 1通过， 2不通过
    @Column(name = "article_check")
    private int articleCheck;
    // 审核评价
    @Column(name = "check_opinion")
    private String checkOpinion;
    // 点赞
    @Column(name = "kudos_number")
    private int kudosNumber;
    // 添加时间
    @Column(name = "create_time")
    private Date createTime;
    // 修改时间
    @Column(name = "update_time")
    private Date updateTime;

    public Article(String title, String words){
        this.title = title;
        this.words = words;
    }
}
