package team.keephealth.yjj.domain.dto;

import lombok.Data;

@Data
public class ArticleInfoDto {

    //id
    private Long id;
    // 标题
    private String title;
    // 内容
    private String words;
    // 图片
    private String pict;
}
