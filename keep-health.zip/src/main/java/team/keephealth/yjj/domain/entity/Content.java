package team.keephealth.yjj.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import team.keephealth.yjj.domain.dto.ArticleInfoDto;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@EqualsAndHashCode(callSuper = false)
@Table(name = "sys_content")
@AllArgsConstructor
@NoArgsConstructor
public class Content {

    @Id
    private Long id;
    // 账号
    private String account;
    // 账号id
    @Column(name = "account_id")
    private Long accountId;
    // 标题
    private String title;
    // 内容
    private String words;
    // 图片
    private String pict;

    public Content(ArticleInfoDto articleInfoDto){
        this.title = articleInfoDto.getTitle();
        this.words = articleInfoDto.getWords();
        this.pict = articleInfoDto.getPict();
    }
}
