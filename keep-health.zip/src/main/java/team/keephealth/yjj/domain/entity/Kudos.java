package team.keephealth.yjj.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Data
@EqualsAndHashCode(callSuper = false)
@Table(name = "sys_kudos")
@AllArgsConstructor
@NoArgsConstructor
public class Kudos {

    @Id
    private Long id;

    // 点赞的账号
    private String visitor;
    // 点赞账号的id
    @Column
    private Long visitorId;

    // 被赞账号
    private String account;
    // 被赞账号id
    @Column
    private Long accountId;

    // 被赞文章
    private String article;
    // 被赞文章id
    @Column
    private Long articleId;
}
