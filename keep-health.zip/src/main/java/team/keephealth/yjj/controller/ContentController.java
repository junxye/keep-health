package team.keephealth.yjj.controller;

import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import team.keephealth.common.annotation.SystemLog;
import team.keephealth.yjj.domain.vo.ResultVo;
import team.keephealth.yjj.service.ContentService;

import javax.annotation.Resource;

@RestController
@RequestMapping("/content")
public class ContentController {

    @Resource
    private ContentService contentService;

    @ApiOperation(value = "获取文章内容")
    @SystemLog(businessName = "获取文章内容")
    @GetMapping("/{articleId}")
    public ResultVo getContent(@PathVariable("articleId") Long articleId){
        return null;
    }
}
