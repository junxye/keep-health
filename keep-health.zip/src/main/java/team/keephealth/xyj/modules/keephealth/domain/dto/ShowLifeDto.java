package team.keephealth.xyj.modules.keephealth.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


@Data
public class ShowLifeDto {

    @ApiModelProperty(value = "动态文字的txt文件url")
    private String textUrl;

}
