package team.keephealth.xyj.modules.keephealth.service;

import com.baomidou.mybatisplus.extension.service.IService;
import team.keephealth.xyj.modules.keephealth.domain.entity.Menu;


/**
 * 菜单表(Menu)表服务接口
 */
public interface MenuService extends IService<Menu> {

}   
