package team.keephealth.xyj.modules.keephealth.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import team.keephealth.common.enums.AppHttpCodeEnum;
import team.keephealth.common.exception.SystemException;
import team.keephealth.common.utils.BeanCopyUtils;
import team.keephealth.common.utils.SecurityUtils;
import team.keephealth.xyj.modules.keephealth.domain.ResponseResult;
import team.keephealth.xyj.modules.keephealth.domain.dto.ShowLifeDto;
import team.keephealth.xyj.modules.keephealth.domain.entity.ShowLife;
import team.keephealth.xyj.modules.keephealth.domain.vo.ShowLifeVo;
import team.keephealth.xyj.modules.keephealth.mapper.ShowLifeMapper;
import team.keephealth.xyj.modules.keephealth.service.ShowLifeService;

/**
 * 用户动态表(ShowLife)表服务实现类
 *
 * @author xyj
 * @since 2022-07-29 19:54:58
 */
@Service("showLifeService")
public class ShowLifeServiceImpl extends ServiceImpl<ShowLifeMapper, ShowLife> implements ShowLifeService {

    @Override
    public ResponseResult addShowLife(ShowLifeDto showLifeDto) {
        if (!StringUtils.hasText(showLifeDto.getTextUrl())){
            throw new SystemException(AppHttpCodeEnum.TEXT_NOT_NULL);
        }
        Long id = SecurityUtils.getLoginUser().getUser().getId();
        ShowLife showLife = BeanCopyUtils.copeBean(showLifeDto, ShowLife.class);
        showLife.setUserId(id);
        save(showLife);
        return ResponseResult.okResult();
    }

    @Override
    public ResponseResult getShowLife() {
        Long id = SecurityUtils.getLoginUser().getUser().getId();
        QueryWrapper<ShowLifeVo> queryWrapper = new QueryWrapper<>();
//        queryWrapper.eq("ksl.state",)

        return ResponseResult.okResult();
    }
}

