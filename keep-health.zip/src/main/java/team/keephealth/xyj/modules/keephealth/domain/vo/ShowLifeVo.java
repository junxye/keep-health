package team.keephealth.xyj.modules.keephealth.domain.vo;

import lombok.Data;

import javax.persistence.Column;
import java.util.Date;

@Data
public class ShowLifeVo {

    private Long kslId;
    //用户id
    private Long userId;

    @Column(name = "u.name")
    private String userName;

    @Column(name = "u.avatar")
    private String userAvatar;

    private String textUrl;
    //审核状态（0为未审核 1为通过审核）
    private String state;

    private Date createTime;

    private Date updateTime;
}
