package team.keephealth.xyj.modules.keephealth.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import team.keephealth.xyj.modules.keephealth.domain.entity.ShowLife;
import org.apache.ibatis.annotations.Mapper;

/**
 * 用户动态表(ShowLife)表数据库访问层
 *
 * @author xyj
 * @since 2022-07-29 19:54:57
 */
@Mapper
public interface ShowLifeMapper extends BaseMapper<ShowLife> {

}

