package team.keephealth.common.enums;

public enum AppHttpCodeEnum {
    // 成功
    SUCCESS(200, "操作成功"),
    // 失败
    ERROR(404, "操作失败"),

    // 登录
    NEED_LOGIN(401, "需要登录后操作"),
    NO_OPERATOR_AUTH(403, "无权限操作"),
    ACCOUNT_NOT_NULL(400100, "账号不得为空"),
    EMAIL_NOT_NULL(400101, "邮箱不得为空"),
    CODE_NOT_NULL(400102, "验证码不得为空"),
    PASSWORD_NOT_NULL(400103, "密码不得为空"),
    TYPE_NOT_NULL(400104, "类型不得为空"),
    PAGE_NUM_NOT_NULL(400105, "页码不得为空"),
    PAGE_SIZE_NOT_NULL(400106, "单页数据量不得为空"),
    USER_ID_NOT_NULL(400107, "被关注者ID不得为空"),
    TEXT_NOT_NULL(400108,"文件url不得为空" ),
    SYSTEM_ERROR(500, "出现错误"),
    FILE_TYPE_ERROR(500100, "文件格式错误"),
    LOGIN_ERROR(500101, "用户名或密码错误"),
    CODE_OVERDUE(500102, "验证码已过期"),
    CODE_INCORRECT(500103, "验证码错误"),

    EMAIL_NOT_RECORD(500104, "邮箱尚未绑定账号,请使用账号密码登录"),
    EMAIL_LOGIN_FAIL(500105, "邮箱登录失败"),
    PASSWORD_LOGIN_FAIL(500106, "账号密码登录失败"),
    ACCOUNT_EXIST(500107, "账号已存在"),
    EMAIL_BINDED(500108, "该邮箱已被其他用户绑定"),
    USER_EMAIL_BINDED(500109, "该用户已绑定过邮箱"),
    STATE_TYPE_ERROR(500110, "状态参数有误（0正常 1停用）"),
    ALREADY_FOLLOWED(500111, "不可重复关注"),
    WATCHED_USER_NOT_EXIST(500112, "该用户不存在"),
    NEVER_WATCHED_USER(500113, "并未关注此人");

    int code;
    String msg;

    AppHttpCodeEnum(int code, String errorMessage) {
        this.code = code;
        this.msg = errorMessage;
    }

    public int getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
