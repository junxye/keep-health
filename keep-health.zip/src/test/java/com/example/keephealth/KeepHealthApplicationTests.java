package com.example.keephealth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KeepHealthApplicationTests {

    @Test
    void contextLoads() {
    }

}
